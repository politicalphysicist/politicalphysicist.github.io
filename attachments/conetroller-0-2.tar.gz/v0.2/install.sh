#!/bin/bash

cp -R usr /