#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  Conetroller 0.2, a program to operate a remote instance of VLC.
#
#  Copyright 2013 Chris MacMackin <cmacmackin@gmail.com>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 3 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  
#  

from gi.repository import Gtk
import sys
import telnetlib
import gobject
import time
import re
import socket
import os
import pickle

gladefile = "/usr/lib/conetroller/interface.glade"
devmode = False

class Conetroller(object):
    def __init__(self):
        self.vlcInst = None
        self.itemLength = 0
        self.updateInterval = 1000  #milliseconds
        self.pausetime = 0.1        #seconds
        self.paused = False
        self.connected = False
        
        builder = Gtk.Builder()
        if devmode:
            builder.add_from_file("./interface.glade")
            print "Operating in development mode"
        else:
            builder.add_from_file(gladefile)
        builder.connect_signals(self)
        
        self.window = builder.get_object("mainWin")
        self.hostEntry = builder.get_object("hostEntry")
        self.portEntry = builder.get_object("portEntry")
        self.passwdEntry = builder.get_object("passwdEntry")
        self.passwdDialogue = builder.get_object("badPasswd")
        self.serverDialogue = builder.get_object("badServer")
        self.connectGroup = builder.get_object("connectGrid")
        self.playlistView = builder.get_object("playlistView")
        self.addSourceGrid = builder.get_object("addSourceGrid")
        self.controlBox = builder.get_object("controlBox")
        self.timeTable = builder.get_object("timeTable")
        self.playbackBox = builder.get_object("playbackBox")
        self.disconnectButton = builder.get_object("disconnectButton")
        self.addSourceEntry = builder.get_object("addSourceEntry")
        self.timeLabel = builder.get_object("time")
        self.timePos = builder.get_object("position")
        self.playIm = builder.get_object("playIm")
        self.backButton = builder.get_object("backButton")
        self.forwardButton = builder.get_object("forwardButton")
        self.stopButton = builder.get_object("stopButton")
        self.playPauseButton = builder.get_object("playPauseButton")
        self.playlistStore = builder.get_object("playlistStore")
        
        self.playlistStore.append(["Items in VLC's queue...", 0])
        self.initialSensitivity()
        self.home = os.getenv("HOME")
        try:
            readin = open(self.home + "/.conetroller", 'rb')
            hostname = pickle.load(readin)
            portnum = pickle.load(readin)
            self.hostEntry.set_text(hostname)
            self.portEntry.set_text(portnum)
        except:
            print "Could not load server data from previous session"
   
    def main(self):
        self.window.show_all()
        Gtk.main()
    
    def onDeleteWindow(self, *args):
        if self.connected:
            self.disconnect()
        writeout = open(self.home + "/.conetroller", 'wb')
        pickle.dump(self.hostEntry.get_text(), writeout)
        pickle.dump(self.portEntry.get_text(), writeout)
        writeout.close()
        Gtk.main_quit(*args)
        
    def changePos(self, scale, scroll, posValue):
        time = int(scale.get_value())
        self.vlcInst.write("seek {0}\n".format(time))

    def skipBack(self, button):
        self.vlcInst.write("prev\n")
        self.playIm.set_from_stock("gtk-media-pause", Gtk.IconSize.BUTTON)
        self.paused = False
    
    def playPause(self, button):
        if self.stopped():
            self.vlcInst.write("play\n")
            gobject.timeout_add(self.updateInterval, self.updateTime)
            self.buttonsSensitive(True)
            self.timeTable.set_sensitive(True)
        else:
            self.vlcInst.write("pause\n")
            self.setPausePlay(not self.paused)
            
        
    def skipForward(self, button):
        self.vlcInst.write("next\n")
        self.playIm.set_from_stock("gtk-media-pause", Gtk.IconSize.BUTTON)
        self.paused = False
    
    def stopPlayback(self, button):
        self.vlcInst.write("stop\n")
        self.buttonsSensitive(False)
        self.timeTable.set_sensitive(False)

        
    def disconnectFromServer(self, button):
        self.disconnect()
        
    def connectToServer(self, button):
        host = self.hostEntry.get_text()
        port = self.portEntry.get_text()
        passwd = self.passwdEntry.get_text()
        try:
            self.vlcInst = telnetlib.Telnet(host, port)
            self.vlcInst.write(passwd + '\n')
            time.sleep(self.pausetime)
            message = self.vlcInst.read_very_eager()
            if message.find('Welcome, Master') == -1:
                self.vlcInst.close()
                self.passwdDialogue.run()
                self.passwdDialogue.hide()
            else:
                self.connectedSensitivity()
                gobject.timeout_add(10000, self.updatePlaylist)
                self.connected = True
                self.updatePlaylist()
                gobject.timeout_add(self.updateInterval, self.updateTime)
        except socket.error:
            print "No VLC instance at this server and port."
            self.serverDialogue.run()
            self.serverDialogue.hide()
    
    def addToPlaylist(self, button):
        state = self.stopped()
        source = self.addSourceEntry.get_text()
        command = "enqueue " + source + "\n"
        self.vlcInst.write(command)
        if state:
            gobject.timeout_add(self.updateInterval, self.updateTime)
            self.buttonsSensitive(False)
        time.sleep(self.pausetime)
        self.updatePlaylist()
    
    def clearPlaylist(self, button):
        self.vlcInst.write("clear\n")
        self.buttonsSensitive(False)
        time.sleep(self.pausetime)
        self.updatePlaylist()
    
    def initialSensitivity(self):
        self.connectGroup.set_sensitive(True)
        self.playlistView.set_sensitive(False)
        self.addSourceGrid.set_sensitive(False)
        self.controlBox.set_sensitive(False)
        
    def connectedSensitivity(self):
        self.connectGroup.set_sensitive(False)
        self.playlistView.set_sensitive(True)
        self.addSourceGrid.set_sensitive(True)
        self.controlBox.set_sensitive(True)
        self.timeTable.set_sensitive(not self.stopped())
        self.buttonsSensitive(not self.stopped())
        self.setPausePlay(self.getPaused())
        self.disconnectButton.set_sensitive(True)

    def getPaused(self):
        self.vlcInst.write('status\n')
        time.sleep(self.pausetime)
        return('paused' in self.vlcInst.read_very_eager())

        
    def stopped(self):
        self.vlcInst.write("is_playing\n")
        time.sleep(self.pausetime)
        stateOutput = int(self.vlcInst.read_very_eager()[-5])
        #print stateOutput
        if stateOutput == 0:
            return True
        else:
            return False
         
    def disconnect(self):
        if type(self.vlcInst) is not type(None):
            self.vlcInst.write("logout\n")
            self.vlcInst.close()
        self.initialSensitivity()
        self.addSourceEntry.set_text("")
        self.connected = False
    
    def updateTime(self):
        if not self.connected or self.stopped():
            self.buttonsSensitive(False)
            self.timeLabel.set_text("0:00:00 / 0:00:00")
            self.timePos.set_value(0.0)
            self.timeTable.set_sensitive(False)
            return False
        else:
            self.vlcInst.read_very_eager()
            self.vlcInst.write('get_time\n')
            time.sleep(self.pausetime)
            timeInSecStr = self.vlcInst.read_eager()[0:-2]
            timeInSec = int(timeInSecStr)
            hrs = (timeInSec / 3600)
            mins = ((timeInSec % 3600) / 60)
            secs = (timeInSec % 60)
            timeOut = "{0}:{1:0>2}:{2:0>2}".format(hrs, mins, secs)
            #print timeOut
            self.vlcInst.read_very_eager()
            self.vlcInst.write('get_length\n')
            time.sleep(self.pausetime)
            lengthInSecStr = self.vlcInst.read_eager()[0:-2]
            lengthInSec = int(lengthInSecStr)
            hrs = (lengthInSec / 3600)
            mins = (lengthInSec % 3600) / 60
            secs = (lengthInSec % 60)
            lengthOut = "{0}:{1:0>2}:{2:0>2}".format(hrs, mins, secs)
            if self.itemLength != lengthInSec:
                self.timePos.set_range(0, lengthInSec)
                self.itemLength = lengthInSec
            self.timeLabel.set_text(timeOut + " / " + lengthOut)
            self.timePos.set_value(float(timeInSec))
            self.vlcInst.read_very_eager()
            return True
    
    def buttonsSensitive(self, state):
        self.backButton.set_sensitive(state)
        self.forwardButton.set_sensitive(state)
        self.stopButton.set_sensitive(state)
        self.setPausePlay(not state)
    
    def updatePlaylist(self):
        if not self.connected:
            return False
        self.vlcInst.read_very_eager()
        self.vlcInst.write("playlist\n")
        time.sleep(3*self.pausetime)
        playlist = self.vlcInst.read_very_eager()
        playlist = re.sub('\+----\[ Playlist - Undefined \]\r\n\| 2 - Playlist\r\n',  
          '', playlist)
        playlist = re.sub('\| 3 - Media Library\r\n\+----\[ End of playlist \]\r\n> ',
          '', playlist)
        contents = playlist.split('\r\n')
        del contents[-1]
        playlistItems =  Gtk.ListStore(str, int)
        for item in contents:
            item = re.sub('\|   ', '', item)
            item = re.sub(' \(([0-9][0-9]:){2}[0-9][0-9]\) \[played [0-9]+ times?\]',
              '', item)
            contents = re.split(' - ', item, 1)
            playlistItems.append([contents[1],int(contents[0])])
        global playlistView
        oldCol = self.playlistView.get_column(0)
        self.playlistView.remove_column(oldCol)
        self.playlistView.set_model(playlistItems)
        cell = Gtk.CellRendererText()
        viewCol = Gtk.TreeViewColumn('Playlist: ', cell, text=0)
        self.playlistView.append_column(viewCol)
        if len(playlistItems) == 0:
            self.playPauseButton.set_sensitive(False)
        elif self.stopped():
            self.playPauseButton.set_sensitive(True)
        self.setPausePlay(self.getPaused())
        return True
        
    def setPausePlay(self, state):
        if state:
            self.playIm.set_from_stock("gtk-media-play", Gtk.IconSize.BUTTON)
            self.paused = True
        else:
            self.playIm.set_from_stock("gtk-media-pause", Gtk.IconSize.BUTTON)
            self.paused = False
    

        
if __name__ == "__main__":
    app = Conetroller()
    app.main()
